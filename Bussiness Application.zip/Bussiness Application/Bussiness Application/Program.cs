﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application
{
    class Program
    {
        static void Main(string[] args)
        {
            // List of user
            List<User> userlist = new List<User>() ;

            // Load Data
            
            Load(userlist);


            // Checking if an admin is already present
            if (!User.checkadminavailability(userlist)) 
            {
                User.Addfirstbootadmin(userlist);
            }

            // Local Variables

            string option ;
            int userindex;
            bool Runtime = true;


            
            // Application Runtime Loop

            while (Runtime) 
            {
                // Main menu

                option = mainmenu();
                if (option == "1")
                {
                    userindex = User.Signin(userlist);
                    if (userindex == 999)
                    {
                        continue ;
                    }

                    // User menu

                    else if(userlist[userindex].usertype == "USER")
                    {
                        option = User.Usermenu();

                        if(option == "7")
                        {
                            User.showuserinfo(userindex, userlist);
                        }
                        else if(option == "8")
                        {
                            User.remove_deleteuser(userlist , userindex);
                        }
                        else if(option == "9")
                        {
                            break;
                        }
                    }

                    // Admin Menu

                    else if(userlist[userindex].usertype == "ADMIN")
                    {
                        option = User.Adminmenu(userlist[userindex].username) ;

                        if(option == "0")
                        {
                            continue;
                        }
                        else if(option == "1")
                        {
                            User.showuserinfo(userindex, userlist);
                        }
                        else if(option == "2")
                        {

                            User.delete_user_by_admin(userlist);
                        }
                        else if(option == "3")
                        {
                            break;
                        }
                    }
                }
                if(option == "2")
                {
                    User.SignUp(userlist);
                    Store(userlist);
                }

                if(option == "3")
                {
                    Store(userlist);
                    System.Environment.Exit(1);
                }
            }
        }



        static string mainmenu()
        {
            string option ;
            Console.WriteLine("1. Sign In");
            Console.WriteLine("2. Sign Up");
            Console.WriteLine("3. Exit \n\n");
            Console.Write("Enter option :");
            option = Console.ReadLine();
            return option;
        }



        static void Store(List<User> userlist)
        {

            StreamWriter file = new StreamWriter("E:\\Data.txt", false);
            
            for (int i = 0; i < userlist.Count; i++)
            {
                if (userlist[i].usertype == "USER")
                {
                    file.WriteLine($"{userlist[i].username},{userlist[i].password},{userlist[i].usertype},{userlist[i].Cnic},{userlist[i].Date},{userlist[i].Phone_no},{userlist[i].Rent},{userlist[i].Food_charges},");
                }
                else
                {
                    file.WriteLine($"{userlist[i].username},{userlist[i].password},{userlist[i].usertype},");
                }
            }

            file.Close();

        }




        static void Load(List<User> userlist)
        {

            string line;
            int commacount = 0;

            StreamReader file = new StreamReader("E:\\Data.txt");

            for(int index = 0; ((line = file.ReadLine()) != null); index++)
            {

                for (int i = 0; i < line.Length; i++)
                {
                    // Comma Count

                    if(line[i] == ',')
                    {
                        commacount ++;
                    }

                    // Username

                    if (line[i] != ',' && commacount == 0)
                    {
                        userlist[index].username = userlist[index].username + line[i];
                    }

                    // Password

                    if (line[i] != ',' && commacount == 1)
                    {
                        userlist[index].password = userlist[index].password + line[i];
                    }

                    // User Type

                    if (line[i] != ',' && commacount == 2)
                    {
                        userlist[index].usertype = userlist[index].usertype + line[i];
                    }


                    if(userlist[index].usertype == "USER")
                    {

                        // Cnic

                        if (line[i] != ',' && commacount == 3)
                        {
                            userlist[index].Cnic = userlist[index].Cnic + line[i];
                        }

                        // Date

                        if (line[i] != ',' && commacount == 4)
                        {
                            userlist[index].Date = userlist[index].Date + line[i];
                        }

                        // Phone number

                        if (line[i] != ',' && commacount == 5)
                        {
                            userlist[index].Phone_no = userlist[index].Phone_no + line[i];
                        }

                        // Rent

                        if (line[i] != ',' && commacount == 5)
                        {
                            userlist[index].Rent = userlist[index].Rent + line[i];
                        }

                        // Food Charges

                        if (line[i] != ',' && commacount == 6)
                        {
                            userlist[index].Food_charges = userlist[index].Food_charges + line[i];
                        }
                    }

                }

            }

            file.Close();

        }


    }

}
