﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application
{
    public class User
    {
        public string username;
        public string password;
        public string usertype;
        public string Cnic;
        public string Phone_no;
        public string Rent;
        public string Food_charges;
        public string Room_no;
        public string Date;

        public User()
        {

        }


        public User(string username_to_assign , string password_to_assign)
        {
            username = username_to_assign;
            password = password_to_assign;
        }



        public static void SignUp(List<User> userlist)
        {
            // Making object for user

            User objectundercheck = new User();
            objectundercheck = takeinputsfornewuser();
            string adminvaliditynote;

            // Return to mainmenu

            if (objectundercheck == null)
            {
                return;
            }

            // User already Registered

            if (CheckUserExistance(objectundercheck.username, userlist))
            {
                useralreadyexists();
                SignUp(userlist);
                return;
            }

            // Admin verification

            adminvaliditynote = checkadminvalidity(userlist);

            // Return to main menu

            if (adminvaliditynote == "back")
            {
                return;
            }

            // Admin not valid

            if (adminvaliditynote == "absent")
            {
                usernotfound();
                SignUp(userlist);
                return;
            }



            // Add user

            userlist.Add(objectundercheck);
            Console.WriteLine("Signed Up Successfully!");
            pause();
        }





        public static int Signin(List<User> userlist)
        {
            string enteredusername;
            string enteredpassword;

            // Taking inputs(Username)

            Console.WriteLine("Enter 00 to return.\n");
            Console.Write("Enter Username: ");
            enteredusername = Console.ReadLine();

            // Return to main menu

            if (enteredusername == "00")
            {
                return 999;
            }

            // Password

            Console.Write("Enter Password: ");
            enteredpassword = Console.ReadLine();

            // Checking Username and Password

            for (int index = 0; index < userlist.Count; index++)
            {
                if (enteredusername == userlist[index].username && enteredpassword == userlist[index].password)
                {
                    return index;
                }
            }

            // For wrong input

            usernotfound();
            return Signin(userlist);

        }





        public static User takeinputsfornewuser()
        {

            // Local variables

            string enteredusername = "";
            string enteredpassword = "";
            string enteredusertype = "";
            string enteredcnic = "";
            string enteredrent = "";
            string entereddate = "";
            string enteredroom_no = "";
            string enteredphone_no = "";
            string enteredfoodcharges = "";

            // Making object from user class

            User newuser = new User();

            // Taking inputs:

            Console.WriteLine("Enter 00 to return.");
            Console.Write("Enter username:   ");
            enteredusername = Console.ReadLine();

            // Return option
            if (enteredusername == "00")
            {
                return null;
            }

            Console.Write("Enter password:   ");
            enteredpassword = Console.ReadLine();
            Console.Write("Enter usertype (admin/user):   ");
            enteredusertype = Console.ReadLine().ToUpper();

            // Client

            if (enteredusertype == "USER")
            {
                Console.Write("Enter CNIC:   ");
                enteredcnic = Console.ReadLine();
                Console.Write("Enter Phone number(11-digits):   ");
                enteredphone_no = Console.ReadLine();
                Console.Write("Enter Room no:   ");
                enteredroom_no = Console.ReadLine();
                Console.Write("Enter Rent for Client:   ");
                enteredrent = Console.ReadLine();
                Console.Write("Enter Food Charges:   ");
                enteredfoodcharges = Console.ReadLine();
                Console.Write("Enter date of joining:   ");
                entereddate = Console.ReadLine();
            }

            else if (enteredusertype == "ADMIN")
            {

            }

            else
            {
                showinvalidinput();
                return null;
            }

            // Filling object attributes

            newuser.Food_charges = enteredfoodcharges;
            newuser.username = enteredusername;
            newuser.password = enteredpassword;
            newuser.usertype = enteredusertype;
            newuser.Phone_no = enteredphone_no;
            newuser.Room_no = enteredroom_no;
            newuser.Cnic = enteredcnic;
            newuser.Rent = enteredrent;
            newuser.Date = entereddate;

            // Return object

            return newuser;
        }





        public static string checkadminvalidity(List<User> userlist)
        {
            int userindex;
            Console.WriteLine("Enter username/password of a former admin for verification\n\n");


            userindex = Signin(userlist);

            if (userindex == 999)
            {
                return "back";
            }

            if (userlist[userindex].usertype == "ADMIN")
            {
                return "present";
            }

            // if not valid former admin

            return "absent";

        }



        public static void Addfirstbootadmin(List<User> userlist)
        {
            User firstbootadmin = new User();

            firstbootadmin.username = "Faizan";
            firstbootadmin.password = "MirZa";
            firstbootadmin.usertype = "ADMIN";

            userlist.Add(firstbootadmin);

        }







        public static void pause()
        {
            Console.Write("Please enter any key to continue....");
            Console.ReadKey();
        }



        public static void remove_deleteuser(List<User> userlist, int userindex)
        {
            userlist.RemoveAt(userindex);
            Console.WriteLine("Successfully removed.");
            pause();
        }







        public static void useralreadyexists()
        {
            Console.WriteLine("Username already registered. Please enter a different username!");
            pause();
        }




        public static void showinvalidinput()
        {
            Console.WriteLine("Invalid input! Please enter a valid input.");
            Console.WriteLine("Press any key to continue....");
            Console.ReadKey();
        }






        public static bool CheckUserExistance(string usernametocheck, List<User> userlist)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                if (userlist[i].username == usernametocheck)
                {
                    return true;
                }
            }

            return false;
        }





        public static void show_all_users(List<User> user_list)
        {
            Console.WriteLine($"Username       Rent        Phone_no        Room_no           Cnic          Date");
            for (int i = 0; i < user_list.Count; i++)
            {
                Console.WriteLine($"{user_list[i].username}       {user_list[i].Rent}        {user_list[i].Phone_no}        {user_list[i].Room_no}           {user_list[i].Cnic}          {user_list[i].Date}");

            }

            pause();

        }





        public static void usernotfound()
        {
            Console.WriteLine("User not found!");
            pause();
        }




        public static string Usermenu()
        {
            string option;

            Console.WriteLine("          ---User Interface---       \n\n");
            Console.WriteLine("0. Return.                               ");
            Console.WriteLine("1. Select food plan.                     ");
            Console.WriteLine("2. Submit a complaint.                   ");
            Console.WriteLine("3. See available rooms.                  ");
            Console.WriteLine("4. See your total payable.               ");
            Console.WriteLine("5. Check date of your joining.           ");
            Console.WriteLine("6. Change username/password.             ");
            Console.WriteLine("7. View your information.                ");
            Console.WriteLine("8. Delete account.                       ");
            Console.WriteLine("9. Exit.                               \n");

            option = Console.ReadLine();

            return option;
        }





        public static void showuserinfo(int userindex, List<User> userlist)
        {
            Console.WriteLine(" Your Information: \n\n");
            Console.WriteLine($"Username:                     {userlist[userindex].username}");
            Console.WriteLine($"Password:                     {userlist[userindex].password}");
            Console.WriteLine($"Phone number:                 {userlist[userindex].Phone_no}");
            Console.WriteLine($"Room no:                      {userlist[userindex].Room_no}");
            Console.WriteLine($"CNIC:                         {userlist[userindex].Cnic}");
            Console.WriteLine($"Rent:                         {userlist[userindex].Rent}");
            Console.WriteLine($"Food Charges:                 {userlist[userindex].Food_charges}");
            Console.WriteLine($"Date if joining:              {userlist[userindex].Date}");


            pause();

        }



        public static bool checkadminavailability(List<User> userlist)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                if (userlist[i].usertype == "ADMIN")
                {
                    return true;
                }
            }

            return false;
        }




        public static string Adminmenu(string name)
        {
            string option;

            Console.WriteLine("---Admin Panal---                      \n\n");
            Console.WriteLine($"               ----Welcome! {name}----\n\n");
            Console.WriteLine("0. Return.                                 ");
            Console.WriteLine("1. See your info.                          ");
            Console.WriteLine("2. Remove a user/admin.                    ");
            Console.WriteLine("3. Exit.                                   ");


            option = Console.ReadLine();
            return option;
        }



        public static void delete_user_by_admin(List<User> user_list)
        {
            string entered_username;
            show_all_users(user_list);
            Console.Write("\n\n Enter username to delete account: ");
            entered_username = Console.ReadLine();

            for (int i = 0; i < user_list.Count; i++)
            {

                if (entered_username ==  user_list[i].username)
                {
                    remove_deleteuser(user_list, i);
                    return;
                }

                Console.WriteLine("Please enter valid usnername!");
                pause();
            }



        }

    }
}
